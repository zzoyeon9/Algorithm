package test;

import java.util.StringTokenizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Kruskal {//Changed SPT to LPT

	static int [] cycletable, parent;
	static int edge, vertex;

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);

		edge = input.nextInt();
		input.nextLine();
		vertex = input.nextInt();
		input.nextLine();

		ArrayList<Edge> graph = new ArrayList<>();
		ArrayList<Edge> spt = new ArrayList<>();

		cycletable = new int[edge+1];
		parent = new int[edge+1];

		for(int i=1;i<=edge;i++)
			parent[i]=i;

		for(int i=0;i<vertex;i++) 
		{
			String temp = input.nextLine();
			StringTokenizer temp2 = new StringTokenizer(temp," ");

			int node0 = Integer.parseInt(temp2.nextToken());
			int node1 = Integer.parseInt(temp2.nextToken());
			int distance = Integer.parseInt( temp2.nextToken());

			Edge edge = new Edge(node0, node1, distance);

			graph.add(edge);
		}

		Collections.sort(graph);

		FindPath(graph, spt);
		
		int sum=0;
		for(int i=0;i<spt.size();i++) {
			sum+=spt.get(i).distance;
		}
		System.out.println(sum);

	}

	static public void FindPath(ArrayList<Edge> graph, ArrayList<Edge> spt) { //0,0���� �ʺ� �켱 Ž�� �Ͽ� �������� �����ϴ� ���� ����� �� �� ������ ��� ī��Ʈ�� ���� ������ ���

		for(int i=0;i<graph.size();i++) {
			if(i==0) 
			{
				spt.add(graph.get(i));
				UpdateCycleTable(graph.get(i).node[0], graph.get(i).node[1], parent);
			}
			else 
			{
				if(!isUnion(graph.get(i).node[0], graph.get(i).node[1])) 
				{
					spt.add(graph.get(i));
					UpdateCycleTable(graph.get(i).node[0], graph.get(i).node[1], parent);
				}
			}
			
		}
	}// 1 3  2 3�θ�   1:1 3:1 
//�� �� ���� �θ� ���� �𿡰� ����
	static public void UpdateCycleTable(int node, int othernode, int[] parent) {

		if(getParent(parent, node)<getParent(parent, othernode))//1 1 //3 - 2 - 2
		{
			parent[getParent(parent, othernode)] = getParent(parent, node);
		}
		else parent[getParent(parent, node)] = getParent(parent, othernode);
	}
	
//������ ����� �θ� ȣ��
	static public int getParent(int [] parent, int node) {

		if(parent[node]==node)
			return node;

		else return getParent(parent, parent[node]);
	}

// �� �θ� �ҷ��� ���� ������ Ȯ��
	static public boolean isUnion(int node0, int node1) {

		if(getParent(parent, node0) == getParent(parent, node1))
			return true;
		
		else return false;
	}

}
class Edge implements Comparable<Edge>{

	int [] node = new int[2];
	int distance;

	public Edge(int a, int b, int dis) {

		this.node[0]=a;
		this.node[1]=b;
		this.distance = dis;
	}
	
	@Override
	public int compareTo(Edge o) {

		if(this.distance>o.distance)
			return -1;

		else if (this.distance>o.distance)
			return 0;

		else return 1;
	}
}